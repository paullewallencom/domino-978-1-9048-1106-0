nd7features.nsf contains the relevant code from chapters 5, 9, and 10 (mostly 10)

Companies.nsf is the Lotus Notes database and code used for Chapter 8, Web Services. 

